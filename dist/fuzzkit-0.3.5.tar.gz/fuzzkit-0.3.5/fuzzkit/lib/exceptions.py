#!/usr/bin/env python
#coding:utf-8
"""
  Author:   --<v1ll4n>
  Purpose: Define the exception!
  Created: 03/21/17
"""

import unittest

########################################################################
class UndefinedValue(Exception):
    """"""
    pass

    

if __name__ == '__main__':
    unittest.main()